package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Race;

public interface RaceRepository extends JpaRepository<Race, Long>{

}
